
<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_admin();

// fetch staff list for assignment
$staff = $mysqli->query("SELECT id, name, email FROM users WHERE role='staff' ORDER BY name")->fetch_all(MYSQLI_ASSOC);

// filters
$statusFilter = $_GET['status'] ?? '';
$staffFilter  = $_GET['staff']  ?? '';

$query = "SELECT l.*, u.name as staff_name FROM leads l LEFT JOIN users u ON u.id=l.assigned_to WHERE 1";
$params = [];
$types = '';
if ($statusFilter !== '') { $query .= " AND l.status=?"; $params[]=$statusFilter; $types.='s'; }
if ($staffFilter !== '')  { $query .= " AND l.assigned_to=?"; $params[]=$staffFilter; $types.='i'; }
$query .= " ORDER BY l.created_at DESC";

$stmt = $mysqli->prepare($query);
if(count($params)>0){ $stmt->bind_param($types, *params); }
$stmt->execute();
$leads = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

include __DIR__ . '/includes/header.php';
?>
<div class="row g-4">
  <div class="col-12">
    <div class="card p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="m-0">Admin Dashboard</h5>
        <div>
          <a class="btn btn-outline-dark btn-sm" href="users.php"><i class="bi bi-people"></i> Manage Staff</a>
        </div>
      </div>

      <div class="row g-3">
        <div class="col-md-6">
          <form class="card p-3" action="actions/lead_upload.php" method="post" enctype="multipart/form-data">
            <h6 class="mb-2">Upload Leads (CSV)</h6>
            <input type="file" name="csv" class="form-control mb-2" accept=".csv" required>
            <div class="text-muted small mb-2">CSV columns: name,email,phone</div>
            <button class="btn btn-dark btn-sm"><i class="bi bi-upload"></i> Upload</button>
          </form>
        </div>
        <div class="col-md-6">
          <form class="card p-3" action="actions/lead_assign.php" method="post" id="bulkAssignForm">
            <h6 class="mb-2">Bulk Assign Selected Leads</h6>
            <input type="hidden" name="lead_ids" id="bulkLeadIds">
            <div class="input-group">
              <select class="form-select" name="assigned_to" required>
                <option value="">Select staff</option>
                <?php foreach($staff as $s): ?>
                  <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['name'] . " (" . $s['email'] . ")"); ?></option>
                <?php endforeach; ?>
              </select>
              <button class="btn btn-dark btn-sm"><i class="bi bi-person-plus"></i> Assign</button>
            </div>
            <div class="small text-muted mt-2">Tick checkboxes in the table and click Assign.</div>
          </form>
        </div>
      </div>

      <hr class="my-4">

      <form class="row g-3 mb-3">
        <div class="col-md-4">
          <label class="form-label">Filter by Status</label>
          <select class="form-select" name="status" onchange="this.form.submit()">
            <option value="">All</option>
            <?php foreach(['new','interested','not_interested','follow_up','closed'] as $st): ?>
              <option value="<?php echo $st; ?>" <?php echo $statusFilter===$st?'selected':''; ?>><?php echo ucfirst(str_replace('_',' ',$st)); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-4">
          <label class="form-label">Filter by Staff</label>
          <select class="form-select" name="staff" onchange="this.form.submit()">
            <option value="">All</option>
            <?php foreach($staff as $s): ?>
              <option value="<?php echo $s['id']; ?>" <?php echo $staffFilter==$s['id']?'selected':''; ?>><?php echo htmlspecialchars($s['name']); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </form>

      <div class="table-responsive">
        <table class="table align-middle">
          <thead>
            <tr>
              <th><input type="checkbox" id="checkAll"></th>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Status</th>
              <th>Remark</th>
              <th>Assigned To</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($leads as $lead): ?>
              <tr>
                <td><input type="checkbox" class="row-check" value="<?php echo $lead['id']; ?>"></td>
                <td><?php echo $lead['id']; ?></td>
                <td><?php echo htmlspecialchars($lead['name']); ?></td>
                <td><?php echo htmlspecialchars($lead['email']); ?></td>
                <td><?php echo htmlspecialchars($lead['phone']); ?></td>
                <td><span class="badge text-bg-secondary badge-status"><?php echo str_replace('_',' ', $lead['status']); ?></span></td>
                <td class="small" style="max-width:240px"><?php echo htmlspecialchars($lead['remark']); ?></td>
                <td><?php echo htmlspecialchars($lead['staff_name'] ?? 'Unassigned'); ?></td>
                <td>
                  <form class="d-flex gap-1" action="actions/lead_update.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $lead['id']; ?>">
                    <select class="form-select form-select-sm" name="status" required>
                      <?php foreach(['new','interested','not_interested','follow_up','closed'] as $st): ?>
                        <option value="<?php echo $st; ?>" <?php echo $lead['status']===$st?'selected':''; ?>><?php echo ucfirst(str_replace('_',' ',$st)); ?></option>
                      <?php endforeach; ?>
                    </select>
                    <input type="text" class="form-control form-control-sm" name="remark" placeholder="Remark" value="<?php echo htmlspecialchars($lead['remark']); ?>">
                    <select class="form-select form-select-sm" name="assigned_to">
                      <option value="">Unassigned</option>
                      <?php foreach($staff as $s): ?>
                        <option value="<?php echo $s['id']; ?>" <?php echo $lead['assigned_to']==$s['id']?'selected':''; ?>><?php echo htmlspecialchars($s['name']); ?></option>
                      <?php endforeach; ?>
                    </select>
                    <button class="btn btn-sm btn-dark"><i class="bi bi-save"></i></button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<script>
const checkAll = document.getElementById('checkAll');
const rows = document.querySelectorAll('.row-check');
const bulkLeadIds = document.getElementById('bulkLeadIds');
checkAll?.addEventListener('change', (e)=>{
  rows.forEach(r => r.checked = checkAll.checked);
  collectIds();
});
rows.forEach(r => r.addEventListener('change', collectIds));
function collectIds(){
  const ids = Array.from(document.querySelectorAll('.row-check:checked')).map(el=>el.value);
  bulkLeadIds.value = ids.join(',');
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
