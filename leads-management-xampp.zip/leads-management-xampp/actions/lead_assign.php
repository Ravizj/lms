
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin();

$lead_ids = $_POST['lead_ids'] ?? '';
$assigned_to = intval($_POST['assigned_to'] ?? 0);

if ($lead_ids && $assigned_to) {
    $ids = array_filter(array_map('intval', explode(',', $lead_ids)));
    if (count($ids) > 0) {
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $types = str_repeat('i', count($ids)+1);
        $stmt = $mysqli->prepare("UPDATE leads SET assigned_to=? WHERE id IN ($placeholders)");
        $params = array_merge([$assigned_to], $ids);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
    }
}
header('Location: ../admin.php');
exit;
?>
