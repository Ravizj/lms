
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_login();

$id = intval($_POST['id'] ?? 0);
$status = $_POST['status'] ?? '';
$remark = trim($_POST['remark'] ?? '');
$assigned_to = $_POST['assigned_to'] ?? null;
$user = $_SESSION['user'];

if ($id > 0 && in_array($status, ['new','interested','not_interested','follow_up','closed'])) {
    // Only admins can reassign; staff can edit only their own leads
    if ($user['role'] === 'admin') {
        if ($assigned_to === '' ) { $assigned_to = null; }
        if ($assigned_to !== null) { $assigned_to = intval($assigned_to); }
        $stmt = $mysqli->prepare("UPDATE leads SET status=?, remark=?, assigned_to=? WHERE id=?");
        $stmt->bind_param('ssii', $status, $remark, $assigned_to, $id);
        $stmt->execute();
        header('Location: ../admin.php');
        exit;
    } else {
        // staff: update only if the lead is assigned to them
        $stmt = $mysqli->prepare("UPDATE leads SET status=?, remark=? WHERE id=? AND assigned_to=?");
        $stmt->bind_param('ssii', $status, $remark, $id, $user['id']);
        $stmt->execute();
        header('Location: ../staff.php');
        exit;
    }
}
header('Location: ../index.php');
exit;
?>
