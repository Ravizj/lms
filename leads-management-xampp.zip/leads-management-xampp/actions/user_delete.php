
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin();

$id = intval($_POST['id'] ?? 0);
if ($id > 0) {
    // Reassign leads to NULL when deleting user
    $stmt = $mysqli->prepare("UPDATE leads SET assigned_to=NULL WHERE assigned_to=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();

    $stmt = $mysqli->prepare("DELETE FROM users WHERE id=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
}
header('Location: ../users.php');
exit;
?>
