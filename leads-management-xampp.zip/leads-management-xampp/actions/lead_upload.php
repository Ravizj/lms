
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin();

if (!isset($_FILES['csv']) || $_FILES['csv']['error'] !== UPLOAD_ERR_OK) {
    header('Location: ../admin.php');
    exit;
}

$filepath = $_FILES['csv']['tmp_name'];
$handle = fopen($filepath, 'r');
if ($handle !== false) {
    // Attempt header detection
    $header = fgetcsv($handle);
    $hasHeader = False;
    if ($header && count($header) >= 3) {
        $first = [strtolower(trim($header[0])), strtolower(trim($header[1])), strtolower(trim($header[2]))];
        if (in_array('name',$first) and in_array('email',$first) and in_array('phone',$first)) {
            $hasHeader = True;
        } else {
            // revert pointer back to start if not header
            fseek($handle, 0);
        }
    } else {
        // no header, rewind
        fseek($handle, 0);
    }

    $stmt = $mysqli->prepare("INSERT INTO leads (name, email, phone) VALUES (?,?,?)");
    while (($row = fgetcsv($handle)) !== false) {
        if (count($row) < 3) continue;
        $name = trim($row[0]); $email = trim($row[1]); $phone = trim($row[2]);
        $stmt->bind_param('sss', $name, $email, $phone);
        $stmt->execute();
    }
    fclose($handle);
}
header('Location: ../admin.php');
exit;
?>
