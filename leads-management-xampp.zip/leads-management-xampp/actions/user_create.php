
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_admin();

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');
$role = $_POST['role'] ?? 'staff';

if ($name && $email && $password) {
    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $mysqli->prepare("INSERT INTO users (name, email, password, role) VALUES (?,?,?,?)");
    $stmt->bind_param('ssss', $name, $email, $hash, $role);
    $stmt->execute();
}
header('Location: ../users.php');
exit;
?>
