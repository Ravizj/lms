
<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_admin();

$users = $mysqli->query("SELECT id, name, email, role, created_at FROM users ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);

include __DIR__ . '/includes/header.php';
?>
<div class="row">
  <div class="col-12">
    <div class="card p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="m-0">Manage Staff</h5>
        <a class="btn btn-outline-secondary btn-sm" href="admin.php">Back</a>
      </div>
      <div class="row g-3">
        <div class="col-md-5">
          <form class="card p-3" action="actions/user_create.php" method="post">
            <h6 class="mb-2">Create User</h6>
            <div class="mb-2">
              <label class="form-label">Name</label>
              <input type="text" class="form-control" name="name" required>
            </div>
            <div class="mb-2">
              <label class="form-label">Email</label>
              <input type="email" class="form-control" name="email" required>
            </div>
            <div class="mb-2">
              <label class="form-label">Password</label>
              <input type="text" class="form-control" name="password" required>
            </div>
            <div class="mb-2">
              <label class="form-label">Role</label>
              <select class="form-select" name="role" required>
                <option value="staff">Staff</option>
                <option value="admin">Admin</option>
              </select>
            </div>
            <button class="btn btn-dark btn-sm"><i class="bi bi-plus"></i> Create</button>
          </form>
        </div>
        <div class="col-md-7">
          <div class="table-responsive">
            <table class="table align-middle">
              <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Created</th><th>Actions</th></tr></thead>
              <tbody>
                <?php foreach($users as $u): ?>
                  <tr>
                    <td><?php echo $u['id']; ?></td>
                    <td><?php echo htmlspecialchars($u['name']); ?></td>
                    <td><?php echo htmlspecialchars($u['email']); ?></td>
                    <td><span class="badge text-bg-info"><?php echo $u['role']; ?></span></td>
                    <td><?php echo $u['created_at']; ?></td>
                    <td>
                      <?php if($u['id'] != $_SESSION['user']['id']): ?>
                      <form action="actions/user_delete.php" method="post" onsubmit="return confirm('Delete user?');">
                        <input type="hidden" name="id" value="<?php echo $u['id']; ?>">
                        <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                      </form>
                      <?php else: ?>
                        <span class="text-muted small">You</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
