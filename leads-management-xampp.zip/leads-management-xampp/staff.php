
<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_login();

$user = $_SESSION['user'];
// staff see only their leads; admin redirected to admin page
if ($user['role']==='admin') { header('Location: admin.php'); exit; }

$statusFilter = $_GET['status'] ?? '';

$query = "SELECT * FROM leads WHERE assigned_to=?";
$params = [$user['id']];
$types = 'i';
if ($statusFilter !== '') { $query .= " AND status=?"; $params[]=$statusFilter; $types.='s'; }
$query .= " ORDER BY created_at DESC";

$stmt = $mysqli->prepare($query);
$stmt->bind_param($types, *params);
$stmt->execute();
$leads = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

include __DIR__ . '/includes/header.php';
?>
<div class="row">
  <div class="col-12">
    <div class="card p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="m-0">My Leads</h5>
      </div>

      <form class="row g-3 mb-3">
        <div class="col-md-4">
          <label class="form-label">Filter by Status</label>
          <select class="form-select" name="status" onchange="this.form.submit()">
            <option value="">All</option>
            <?php foreach(['new','interested','not_interested','follow_up','closed'] as $st): ?>
              <option value="<?php echo $st; ?>" <?php echo $statusFilter===$st?'selected':''; ?>><?php echo ucfirst(str_replace('_',' ',$st)); ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </form>

      <div class="table-responsive">
        <table class="table align-middle">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Status</th>
              <th>Remark</th>
              <th>Update</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach($leads as $lead): ?>
              <tr>
                <td><?php echo $lead['id']; ?></td>
                <td><?php echo htmlspecialchars($lead['name']); ?></td>
                <td><?php echo htmlspecialchars($lead['email']); ?></td>
                <td><?php echo htmlspecialchars($lead['phone']); ?></td>
                <td><span class="badge text-bg-secondary badge-status"><?php echo str_replace('_',' ', $lead['status']); ?></span></td>
                <td class="small" style="max-width:240px"><?php echo htmlspecialchars($lead['remark']); ?></td>
                <td>
                  <form class="d-flex gap-1" action="actions/lead_update.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $lead['id']; ?>">
                    <select class="form-select form-select-sm" name="status" required>
                      <?php foreach(['new','interested','not_interested','follow_up','closed'] as $st): ?>
                        <option value="<?php echo $st; ?>" <?php echo $lead['status']===$st?'selected':''; ?>><?php echo ucfirst(str_replace('_',' ',$st)); ?></option>
                      <?php endforeach; ?>
                    </select>
                    <input type="text" class="form-control form-control-sm" name="remark" placeholder="Remark" value="<?php echo htmlspecialchars($lead['remark']); ?>">
                    <button class="btn btn-sm btn-dark"><i class="bi bi-save"></i></button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
