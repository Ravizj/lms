
<?php
// includes/header.php
if (session_status() === PHP_SESSION_NONE) { session_start(); }
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Leads Manager</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body { background: #f7f9fc; }
    .navbar { box-shadow: 0 2px 8px rgba(0,0,0,.06); }
    .card { border: 0; box-shadow: 0 8px 24px rgba(0,0,0,.05); border-radius: 1rem; }
    .badge-status { text-transform: capitalize; }
    .table thead th { white-space: nowrap; }
    .rounded-2xl { border-radius: 1rem; }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-white mb-4">
  <div class="container-fluid">
    <a class="navbar-brand fw-bold" href="<?php echo isset($_SESSION['user']) ? ( $_SESSION['user']['role']==='admin' ? 'admin.php' : 'staff.php' ) : 'login.php'; ?>">
      <i class="bi bi-kanban"></i> Leads Manager
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="nav">
      <ul class="navbar-nav ms-auto">
        <?php if(isset($_SESSION['user'])): ?>
          <li class="nav-item me-3"><span class="nav-link">Hi, <?php echo htmlspecialchars($_SESSION['user']['name']); ?></span></li>
          <li class="nav-item"><a class="btn btn-sm btn-outline-dark" href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</nav>
<div class="container mb-5">
