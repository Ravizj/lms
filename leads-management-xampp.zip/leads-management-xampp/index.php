
<?php
require_once __DIR__ . '/includes/auth.php';
if (is_logged_in()) {
  if ($_SESSION['user']['role']==='admin') { header('Location: admin.php'); }
  else { header('Location: staff.php'); }
  exit;
}
header('Location: login.php');
?>
