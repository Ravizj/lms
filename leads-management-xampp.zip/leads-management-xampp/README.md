
# Leads Management (XAMPP / PHP + MySQL)

A simple, clean web app to manage leads with Admin & Staff roles. Works out-of-the-box on XAMPP.

## Features
- Admin: upload CSV, create/delete users, assign leads (single & bulk), update status & remark
- Staff: see assigned leads, update status & remark
- Filters by status and staff
- Bootstrap 5 UI

## Quick Setup (XAMPP on Windows)
1. Start Apache & MySQL in XAMPP.
2. Create database `leads_db` in phpMyAdmin.
3. Import `db.sql` into `leads_db`.
4. Copy the `leads-management-xampp` folder into `C:\xampp\htdocs\` (or `/opt/lampp/htdocs/` on Linux).
5. Go to `http://localhost/leads-management-xampp/`.
6. Login: `admin@example.com` / `admin123`.
7. Update DB credentials in `config.php` if needed.

## CSV Format
```
name,email,phone
Ravi Kumar,ravi@example.com,9876543210
...
```

## Notes
- Default MySQL root password on XAMPP is empty. If you changed it, update `config.php`.
- For production, create a non-root MySQL user and a strong admin password.
- This is a minimal app; add CSRF tokens, stronger validation, and logs for production.
