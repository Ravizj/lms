
<?php
// config.php
// Update these for your XAMPP MySQL
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = ''; // XAMPP default is empty password for root
$DB_NAME = 'leads_db';

$BASE_URL = ''; // e.g., '/leads-app' if you put app into htdocs/leads-app
?>
